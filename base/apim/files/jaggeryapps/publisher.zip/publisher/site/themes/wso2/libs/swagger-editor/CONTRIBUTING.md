# Contributing to Swagger Editor

### Issues
File issues in GitHub's to report bugs or issue a pull request.

### Licensing
All contributions must grant copyright permission to this project, the source of which is declared to be under an Apache 2 license (see [LICENSE](./LICENSE)).
